const { MessageEmbed } = require('discord.js');
const Discord = require('discord.js');
const Beautify = require('beautify');
const config = require('../config.json');

module.exports.run = async (client, message, args) => {
  if (message.author.bot) return;
  let prefix = config.prefix;
  if (!message.content.startsWith(prefix)) return;

  if (message.author.id !== "721355948135809148") {
    return message.channel.send("**Ova komanda je samo za `Vlasnika`.**");
  }

  if (!args[0]) {
    message.channel.send("Morate proceniti _**NESTO**_ Molim vas!");
  }

  try {
    if (args.join(" ").toLowerCase().includes("token")) {
      return;
    }

    const toEval = args.join(" ");
    const evaluated = eval(toEval);

    let embed = new Discord.MessageEmbed()
      .setTitle("Procena")
      .addField("Za Procenu", `\`\`\`js\n${Beautify(args.join(" "), { format: "js" })}\n\`\`\``)
      .addField("Procenjeno", evaluated)
      .addField("Tip:", typeof (evaluated))
      .setTimestamp()
      .setFooter(`${message.author.tag}`, client.user.displayAvatarURL());
    message.channel.send(embed);

  } catch (e) {
    let errorembed = new Discord.MessageEmbed()
      .addField(":x: Greška!")
      .setDescription(e)
      .setTimestamp()
      .setFooter(`${message.author.tag}`, client.user.displayAvatarURL());
    message.channel.send(errorembed);
  }
};
