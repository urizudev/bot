const Discord = require('discord.js');
const config = require('../config.json');

module.exports.run = async (client, message, args) => {
  if (message.author.bot) return;
  let prefix = config.prefix;
  if (!message.content.startsWith(prefix)) return;

  let help = new Discord.MessageEmbed()
    .setAuthor("oxyzzz__")
    .setTitle("**Giveaway Bot Commands :**", true)
    .addField("🎁 Giveaway", `${prefix}start [channel-name] [Time] [winners] [Prize]\n${prefix}reroll [prize name]\n${prefix}end [prize name]\n${prefix}kick [user mention]\n${prefix}ban [user mention]\n${prefix}timeout [user mention]`, false)
    .addField("💫 Examples", `${prefix}start #giveaway 5m 1 Testing\n${prefix}end Testing\n${prefix}reroll Testing\n${prefix}kick @user\n${prefix}ban @user\n${prefix}timeout @user`, false)
    .addField("🛠️ Utility", `${prefix}ping`, false)
    .addField("ℹ Information", `${prefix}stats`, false)
    .setTimestamp()
    .setThumbnail(client.user.avatarURL({
      size: 4096,
      format: 'png'
    }))
    .setFooter("Made by oxyzzz__");

  message.channel.send(`> ↬ **Poslao sam komande u tvoj DM** 📥\n> ↬ **Ako ne dobijete poruku, otvorite svoj DM 🔓**`);

  return message.author.send(help);
}

module.exports.help = {
  name: "help"
}
