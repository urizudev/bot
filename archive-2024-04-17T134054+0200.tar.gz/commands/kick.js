const Discord = require('discord.js');
const config = require('../config.json');

module.exports.run = async (client, message, args) => {
  if (message.author.bot) return;
  let prefix = config.prefix;
  if (!message.content.startsWith(prefix)) return;

  // Provera dozvola
  if (!message.member.hasPermission('KICK_MEMBERS')) {
    return message.channel.send('**:x: Nemate dozvolu `KICK_MEMBERS` za izbacivanje clanova.**');
  }

  // Provera argumenta
  if (args.length === 0) {
    return message.channel.send('**:x: Morate navesti korisnika kojeg zelite da izbacite.**');
  }

  // Pretraga korisnika
  let member = message.mentions.members.first();
  if (!member) {
    return message.channel.send('**:x: Ne mogu pronaci navedenog korisnika.**');
  }

  // Provera da li je korisnik izbaciv
  if (!member.kickable) {
    return message.channel.send('**:x: Nemoguce je izbaciti ovog korisnika.**');
  }

  // Izabaci korisnika
  await member.kick('Nepozeljno ponasanje.')
    .then(() => {
      message.channel.send(`:white_check_mark: **${member.user.tag}** je uspesno izbacen.`);
    })
    .catch(error => {
      console.error('Greska prilikom izbacivanja:', error);
      message.channel.send('**:x: Doslo je do greske prilikom izbacivanja korisnika.**');
    });
};

module.exports.help = {
  name: "kick"
};
