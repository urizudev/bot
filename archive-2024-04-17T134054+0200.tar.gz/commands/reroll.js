const ms = require('ms');

exports.run = async (client, message, args) => {

    // Ako clan nema dovoljno dozvola
    if(!message.member.hasPermission('MANAGE_MESSAGES') && !message.member.roles.cache.some((r) => r.name === "Giveaways")){
        return message.channel.send('**:x: Nemate dozvolu `Upravljanje Porukama`.**');
    }

    // Ako nije specificiran ID poruke ili ime nagradne igre
    if(!args[0]){
        return message.channel.send(':x: Morate specificirati validan ID poruke!');
    }

    // Pokusaj da pronadjes nagradnu igru po nagradi, a zatim po ID-u
    let giveaway = 
    // Trazi po nagradi nagradne igre
    client.giveawaysManager.giveaways.find((g) => g.prize === args.join(' ')) ||
    // Trazi po ID-u nagradne igre
    client.giveawaysManager.giveaways.find((g) => g.messageID === args[0]);

    // Ako nije pronadjena nagradna igra
    if(!giveaway){
        return message.channel.send('Nije moguce pronaci nagradnu igru za `'+ args.join(' ') +'`.');
    }

    // Ponovo izvlacenje nagradne igre
    client.giveawaysManager.reroll(giveaway.messageID)
    .then(() => {
        // Poruka o uspehu
        message.channel.send('Nagradna igra ponovo izvucena!');
    })
    .catch((e) => {
        if(e.startsWith(`Nagradna igra sa ID-om poruke ${giveaway.messageID} nije zavrsena.`)){
            message.channel.send('Ova nagradna igra nije zavrsena!');
        } else {
            console.error(e);
            message.channel.send('Doslo je do greske...');

        }
    });

};
