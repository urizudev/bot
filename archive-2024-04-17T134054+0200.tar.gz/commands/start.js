const ms = require('ms');

exports.run = async (client, message, args) => {

  // Ako clan nema dovoljno dozvola
  if (!message.member.hasPermission('MANAGE_MESSAGES') && !message.member.roles.cache.some((r) => r.name === "Giveaways")) {
    return message.channel.send('**:x: Nemate dozvolu `Upravljanje Porukama`.**');
  }

  // Kanal za nagradne igre
  let giveawayChannel = message.mentions.channels.first();
  // Ako nije pomenut kanal
  if (!giveawayChannel) {
    return message.channel.send(':x: Morate oznaciti validan kanal!');
  }

  // Trajanje nagradne igre
  let giveawayDuration = args[1];
  // Ako trajanje nije validno
  if (!giveawayDuration || isNaN(ms(giveawayDuration))) {
    return message.channel.send(':x: Morate specificirati validno trajanje!');
  }

  // Broj pobednika
  let giveawayNumberWinners = args[2];
  // Ako broj pobednika nije broj
  if (isNaN(giveawayNumberWinners) || (parseInt(giveawayNumberWinners) <= 0)) {
    return message.channel.send(':x: Morate specificirati validan broj pobednika!');
  }

  // Nagrada za nagradnu igru
  let giveawayPrize = args.slice(3).join(' ');
  // Ako nije specificirana nagrada
  if (!giveawayPrize) {
    return message.channel.send(':x: Morate specificirati validnu nagradu!');
  }

  // Pokreni nagradnu igru
  client.giveawaysManager.start(giveawayChannel, {
    // Trajanje nagradne igre
    time: ms(giveawayDuration),
    // Nagrada za nagradnu igru
    prize: giveawayPrize,
    // Broj pobednika nagradne igre
    winnerCount: parseInt(giveawayNumberWinners),
    // Ko organizuje ovu nagradnu igru
    hostedBy: client.config.hostedBy ? message.author : null,
    // Poruke
    messages: {
      giveaway: (client.config.everyoneMention ? "<@721355948135809148>\n\n" : "") + "🎉 **NAGRADNA IGRA** 🎉",
      giveawayEnded: (client.config.everyoneMention ? "<@721355948135809148>\n\n" : "") + "🎉 **NAGRADNA IGRA ZAVRSENA** 🎉",
      timeRemaining: "Preostalo vreme: **{duration}**!",
      inviteToParticipate: "Reagujte sa 🎉 da ucestvujete!",
      winMessage: "**Cestitamo, {winners} Osvojili ste `{prize}`** !",
      embedFooter: "Legende",
      noWinner: "Nema dovoljno ucesnika da se odredi pobednik!",
      hostedBy: "Organizovano od strane: {user}",
      winners: "pobednika ",
      endedAt: "Zavrseno u",
      units: {
        seconds: "sekundi",
        minutes: "minuta",
        hours: "sati",
        days: "dana",
        pluralS: false // Nije potrebno, jer se jedinice zavrsavaju sa S pa ce automatski biti uklonjene ako je vrednost jedinice manja od 2
      }
    }
  });
};
