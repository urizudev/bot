const Discord = require('discord.js');
const config = require('../config.json');
const os = require('os');

module.exports.run = async (client, message, args) => {
  if (message.author.bot) return;
  let prefix = config.prefix;
  if (!message.content.startsWith(prefix)) return;

  let brojServera = client.guilds.cache.size;
  let brojKorisnika = client.users.cache.size;
  let brojKanala = client.channels.cache.size;
  let arhitektura = os.arch();
  let platforma = os.platform();
  let shardovi = client.ws.shards.size;
  let NodeVerzija = process.version;
  let brojJezgara = os.cpus().length;

  // Ako clan nema dovoljno dozvola
  if (!message.member.hasPermission('MANAGE_MESSAGES') && !message.member.roles.cache.some((r) => r.name === "Giveaways")) {
    return message.channel.send('**:x: Nemate dozvolu `Upravljanje Porukama`.**');
  }

  let statistika = new Discord.MessageEmbed()
    .setAuthor('Od : oxyzzz__')
    .setTitle(`Statistika ${client.user.username}`)
    .setColor('RED')
    .addField("Broj Servera", `${brojServera}`, true)
    .addField("Broj Korisnika", `${brojKorisnika}`, true)
    .addField("Broj Kanala", `${brojKanala}`, true)
    .addField("Arhitektura", `${arhitektura}`, true)
    .addField("Platforma", `${platforma}`, true)
    .addField("Broj Shardova", `${shardovi}`, true)
    .addField("Verzija Node-a", `${NodeVerzija}`, true)
    .addField("Broj Jezgara", `${brojJezgara}`, true)
    .setTimestamp()
    .setFooter(`${message.author.tag}`, message.author.displayAvatarURL());
  message.channel.send(statistika);
};

module.exports.help = {
  name: "stats"
};
