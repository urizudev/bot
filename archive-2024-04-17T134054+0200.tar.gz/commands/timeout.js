const Discord = require('discord.js');
const config = require('../config.json');

module.exports.run = async (client, message, args) => {
  if (message.author.bot) return;
  let prefix = config.prefix;
  if (!message.content.startsWith(prefix)) return;

  // Provera dozvola
  if (!message.member.hasPermission('MANAGE_ROLES')) {
    return message.channel.send('**:x: Nemate dozvolu `MANAGE_ROLES` za davanje uloga.**');
  }

  // Provera argumenta
  if (args.length === 0) {
    return message.channel.send('**:x: Morate navesti korisnika kojeg zelite da timeoutujete.**');
  }

  // Pretraga korisnika
  let member = message.mentions.members.first();
  if (!member) {
    return message.channel.send('**:x: Ne mogu pronaci navedenog korisnika.**');
  }

  // Provera da li je korisnik izbaciv
  if (!member.bannable) {
    return message.channel.send('**:x: Nemoguce je timeoutovati ovog korisnika.**');
  }

  // Izabaci korisnika
  await member.roles.add(config.mutedRoleID)
    .then(() => {
      message.channel.send(`:white_check_mark: **${member.user.tag}** je uspesno timeoutovan.`);
    })
    .catch(error => {
      console.error('Greska prilikom timeoutovanja:', error);
      message.channel.send('**:x: Doslo je do greske prilikom timeoutovanja korisnika.**');
    });
};

module.exports.help = {
  name: "timeout"
};
